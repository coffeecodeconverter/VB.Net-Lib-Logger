﻿

Imports System.Runtime.CompilerServices

Public Class Form1



    Private Async Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ' NOTE: Usually, we don't need to set MinimumLevel here anymore 
        ' because LoadConfiguration() in VB class handles it via App.config!
        ' Only set it here if you want to OVERRIDE the config file for testing.

        ' VB.MinimumLevel = LogLevel.Trace
        VB.Log("Application Started", LogLevel.Info)
    End Sub



    Private Sub testFunction(msg As String, yesNo As Boolean)
        VB.LogFunctionCall({msg, yesNo})

        Try
            Debug.WriteLine("testFunction starting...")

            ' TEST - uncomment to trigger an error intentionally. 
            'Dim zero As Integer = 0
            'Dim crashMe As Integer = 10 \ zero

            VB.Log("just a string within testFunction() called as INFO")

        Catch ex As Exception
            VB.Log($"Crash in testFunction: {msg}", LogLevel.Err, ex)
        End Try
    End Sub



    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        testFunction("Triggering a crash", True)
        'VB.Log("testing just a string")
        'VB.LogInfo("testing logInfo() just a string")
    End Sub



    Private Sub Form1_FormClosing(sender As Object, e As FormClosingEventArgs) Handles Me.FormClosing
        VB.Log("Application closing by user.", LogLevel.Info)
        VB.Shutdown(True)
    End Sub


End Class
