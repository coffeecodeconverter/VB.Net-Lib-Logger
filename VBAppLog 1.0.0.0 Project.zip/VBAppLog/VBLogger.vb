﻿

' NOTE:
' you must manually add these references: 
' System.Configuration 
' System.Web.Extensions
' System.Runtime.Caching



Imports System.IO
Imports System.Text
Imports System.Collections.Concurrent
Imports System.Runtime.CompilerServices
Imports System.Threading ' Fixed: Added for CancellationTokenSource and Thread
Imports System.Web.Script.Serialization ' Requires Reference: System.Web.Extensions
Imports System.Configuration



Public Enum LogLevel
    Trace = 0
    Debug = 1
    Info = 2
    Warn = 3
    Err = 4
    Fatal = 5
End Enum

Public Enum LogFormat
    PlainText
    NDJSON
End Enum



Public Class VB

    ' --- Configuration ---
    Public Shared LogFileName As String = "Application"
    Public Shared MinimumLevel As LogLevel = LogLevel.Info
    Public Shared OutputDirectory As String = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Logs")
    Public Shared RetentionDays As Integer = 7
    Public Shared Format As LogFormat = LogFormat.NDJSON
    Public Shared IncludeTimestamp As Boolean = True
    Public Shared ShowUIOnFallback As Boolean = True



    Public Structure LogEntry
        Public Timestamp As DateTime
        Public Level As LogLevel
        Public Message As String
        Public MemberName As String
        Public Args As Object()
        Public Exception As Exception
    End Structure



    Private Shared ReadOnly _logQueue As New ConcurrentQueue(Of LogEntry)
    Private Shared ReadOnly _writerLock As New Object()
    Private Shared _backgroundTask As Task
    Private Shared _cancellationTokenSource As New CancellationTokenSource()
    Private Shared _isClosing As Boolean = False




    Shared Sub New()
        LoadConfiguration()
        _backgroundTask = Task.Run(AddressOf ProcessQueue)
        AddHandler AppDomain.CurrentDomain.ProcessExit, Sub() Shutdown(True)
        Log($"=== Logger Initialized (Format: {Format}, MinLevel: {MinimumLevel}) ===", LogLevel.Info)
    End Sub





    Public Shared Sub LoadConfiguration()
        Try
            Dim name = ConfigurationManager.AppSettings("LogFileName")
            If Not String.IsNullOrEmpty(name) Then LogFileName = name

            Dim pathSetting = ConfigurationManager.AppSettings("LogPath")
            If Not String.IsNullOrEmpty(pathSetting) Then OutputDirectory = pathSetting

            Dim days = ConfigurationManager.AppSettings("RetentionDays")
            If Not String.IsNullOrEmpty(days) Then Integer.TryParse(days, RetentionDays)

            Dim fmt = ConfigurationManager.AppSettings("LogFormat")?.ToLower()
            If fmt = "ndjson" OrElse fmt = "2" Then
                Format = LogFormat.NDJSON
            ElseIf fmt = "text" OrElse fmt = "1" Then
                Format = LogFormat.PlainText
            End If

            Dim lvl = ConfigurationManager.AppSettings("MinimumLevel")
            If Not String.IsNullOrEmpty(lvl) Then
                [Enum].TryParse(Of LogLevel)(lvl, True, MinimumLevel)
            End If

        Catch ex As Exception
            Diagnostics.Debug.WriteLine("Logger failed to load config: " & ex.Message)
        End Try
    End Sub




    ' --- Public API ---
    Public Shared Sub Log(message As String,
                         Optional level As LogLevel = LogLevel.Info,
                         Optional ex As Exception = Nothing)

        If level < MinimumLevel Then Return

        Dim entry As New LogEntry With {
            .Timestamp = DateTime.Now,
            .Level = level,
            .Message = message,
            .Exception = ex
        }

        If level = LogLevel.Fatal Then
            WriteImmediately(entry)
        Else
            _logQueue.Enqueue(entry)
        End If
    End Sub




    Public Shared Sub LogInfo(msg As String, Optional ex As Exception = Nothing)
        ' 'ex' argument is ignored, only added to the signature for easy refactoring with LogError() below
        Log(msg, LogLevel.Info)
    End Sub




    Public Shared Sub LogError(msg As String, ex As Exception)
        ' ensures you can't forget to pass the logLevel 
        Log(msg, LogLevel.Err, ex)
    End Sub





    Public Shared Async Function LogAsync(message As String,
                                     Optional level As LogLevel = LogLevel.Info,
                                     Optional ex As Exception = Nothing) As Task
        Await Task.Run(Sub() Log(message, level, ex))
    End Function




    Public Shared Sub LogFunctionCall(args As Object(),
                                     <CallerMemberName> Optional memberName As String = "")
        If LogLevel.Trace < MinimumLevel Then Return

        _logQueue.Enqueue(New LogEntry With {
            .Timestamp = DateTime.Now,
            .Level = LogLevel.Trace,
            .Message = $"Function Entry",
            .MemberName = memberName,
            .Args = args
        })
    End Sub




    ' --- Core Logic ---
    Private Shared Sub ProcessQueue()
        Try
            While Not _cancellationTokenSource.Token.IsCancellationRequested
                FlushQueue()
                Thread.Sleep(100)
            End While
        Catch ex As OperationCanceledException
            ' Normal shutdown
        End Try
    End Sub




    Private Shared Sub FlushQueue()
        Dim entry As LogEntry = Nothing
        While _logQueue.TryDequeue(entry)
            WriteToDisk(entry)
        End While
    End Sub




    Private Shared Sub WriteToDisk(entry As LogEntry)
        SyncLock _writerLock
            Dim logPath As String = GetCurrentLogPath()
            Try
                Dim dir = Path.GetDirectoryName(logPath)
                If Not Directory.Exists(dir) Then Directory.CreateDirectory(dir)

                Using sw As New StreamWriter(logPath, True, Encoding.UTF8)
                    ' Write the formatted JSON (and indented args)
                    sw.WriteLine(FormatLine(entry))

                    ' Write indented Stack Trace if an exception exists
                    If entry.Exception IsNot Nothing Then
                        sw.WriteLine(FormatStackTrace(entry.Exception))
                    End If
                End Using
            Catch ex As Exception
                HandleFallback(entry, ex.Message)
            End Try
        End SyncLock
    End Sub




    Private Shared Sub WriteImmediately(entry As LogEntry)
        WriteToDisk(entry)
        If entry.Level = LogLevel.Fatal Then Shutdown(True)
    End Sub




    Private Shared Sub HandleFallback(entry As LogEntry, originalError As String)
        Dim fallbackDir As String = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "VBNetLogger")
        Dim fallbackPath As String = Path.Combine(fallbackDir, $"{DateTime.Now:yyyy-MM-dd}_{LogFileName}.log")

        Try
            If Not Directory.Exists(fallbackDir) Then Directory.CreateDirectory(fallbackDir)
            File.AppendAllText(fallbackPath, $"[FALLBACK - REASON: {originalError}] " & FormatLine(entry) & Environment.NewLine)

            If ShowUIOnFallback Then
                ShowUIOnFallback = False
                Task.Run(Sub() MsgBox($"Logger fell back to LocalAppData because: {originalError}", MsgBoxStyle.Critical))
            End If
        Catch
            Diagnostics.Debug.WriteLine("FATAL LOGGER FAILURE: " & entry.Message)
        End Try
    End Sub




    ' --- Formatting ---
    Private Shared Function FormatLine(entry As LogEntry) As String
        Dim ts As String = If(IncludeTimestamp, entry.Timestamp.ToString("yyyy-MM-dd HH:mm:ss.fff") & " ", "")

        If Format = LogFormat.NDJSON Then
            Dim js As New JavaScriptSerializer()
            Dim dict As New Dictionary(Of String, Object)

            ' Standard JSON fields
            dict.Add("dateTime", entry.Timestamp.ToString("yyyy-MM-dd HH:mm:ss.fff"))
            dict.Add("logLevel", entry.Level.ToString())
            dict.Add("msg", entry.Message)

            If Not String.IsNullOrEmpty(entry.MemberName) Then
                dict.Add("func", entry.MemberName)
            End If

            If entry.Exception IsNot Nothing Then
                dict.Add("ex", entry.Exception.Message)
            End If

            ' Create the JSON string
            Dim sb As New StringBuilder()
            sb.Append(js.Serialize(dict))

            ' Append arguments as indented text lines below the JSON
            If entry.Args IsNot Nothing AndAlso entry.Args.Length > 0 Then
                For Each a In entry.Args
                    sb.AppendLine()
                    sb.Append("    ") ' Indentation
                    ' Use JS Serialize for args to get proper quotes/casing (e.g. "string", true)
                    sb.Append(js.Serialize(a))
                Next
            End If

            Return sb.ToString()
        Else
            Dim sb As New StringBuilder()

            ' 1. Create the main header line
            Dim header = $"{ts}{entry.Level.ToString().ToUpper()} {entry.Message}"
            If Not String.IsNullOrEmpty(entry.MemberName) Then
                header &= $" [Func: {entry.MemberName}()]"
            End If

            ' 2. Add the "Arguments Passed" suffix if there is data in the array
            If entry.Args IsNot Nothing AndAlso entry.Args.Length > 0 Then
                header &= " - Arguments Passed:"
                sb.Append(header)

                ' 3. Append arguments on new, indented lines
                For Each a In entry.Args
                    sb.AppendLine()
                    sb.Append("    ")
                    sb.Append(If(a Is Nothing, "null", a.ToString()))
                Next
            Else
                ' No arguments, just append the header
                sb.Append(header)
            End If

            Return sb.ToString()
        End If
    End Function



    Private Shared Function FormatStackTrace(ex As Exception) As String
        Dim sb As New StringBuilder()
        sb.AppendLine($"    {ex.GetType().Name}: {ex.Message}")
        Dim lines = ex.StackTrace.Split({Environment.NewLine}, StringSplitOptions.RemoveEmptyEntries)
        For Each line In lines
            sb.AppendLine($"        {line.Trim()}")
        Next
        Return sb.ToString()
    End Function




    ' --- Maintenance ---
    Private Shared Function GetCurrentLogPath() As String
        Return Path.Combine(OutputDirectory, $"{DateTime.Now:yyyy-dd-MM}_{LogFileName}.log")
    End Function





    Public Shared Sub CleanOldLogs()
        Try
            If Not Directory.Exists(OutputDirectory) Then Return
            ' Search specifically for our log files
            Dim files = Directory.GetFiles(OutputDirectory, $"*_{LogFileName}.log")
            For Each f In files
                Dim fi As New FileInfo(f)
                ' If the file is older than our retention setting
                If fi.CreationTime < DateTime.Now.AddDays(-RetentionDays) Then
                    Try
                        fi.Delete()
                    Catch
                        ' If a file is open in Notepad, we can't delete it. 
                        ' Skip it and try again tomorrow.
                    End Try
                End If
            Next
        Catch
            ' Total silence here to prevent the "Logger Loop"
        End Try
    End Sub




    Public Shared Sub Shutdown(Optional flush As Boolean = True)
        If _isClosing Then Return
        _isClosing = True
        If flush Then FlushQueue()
        _cancellationTokenSource.Cancel()
        CleanOldLogs()
    End Sub
End Class




' NOTES:
' think "lower level = more detail" - everything above your level is included. 

'Trace	            Used For LogFunctionCall. Extremely noisy. Only turn this On When you are hunting a specific bug In a specific Function.
'Debug              "Checkpoint" logs For developers. e.g., VB.Log("Database connection string built").
'Info(The Default)  High-level business events. e.g., VB.Log("User 'abc123' logged in") Or VB.Log("Report generated successfully").
'Warn	            Something Is "wrong" but the app didn't crash. e.g., VB.Log("API took 5 seconds to respond - slow connection").
'Err	            An operation failed. A Try/Catch was triggered. The user likely saw an Error message.
'Fatal	            The app Is about To close because Of a catastrophic failure (e.g., Database Is gone).